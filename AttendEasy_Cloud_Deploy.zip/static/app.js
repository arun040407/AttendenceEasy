// Attendance Application JavaScript

document.addEventListener('DOMContentLoaded', function () {
  initAttendanceTable();
  initSearchAndFilter();
  initModals();
});

// Manage Attendance Table Interactivity
function initAttendanceTable() {
  const table = document.getElementById('attendanceTable');
  if (!table) return;

  // Track changes to show unsaved changes indicator
  let hasUnsavedChanges = false;
  window.addEventListener('beforeunload', function (e) {
    if (hasUnsavedChanges) {
      e.preventDefault();
      e.returnValue = '';
    }
  });

  const form = document.getElementById('attendanceForm');
  if (form) {
    form.addEventListener('submit', function () {
      hasUnsavedChanges = false;
    });
  }

  // Handle clicking on status pills
  table.addEventListener('click', function (e) {
    const pill = e.target.closest('.status-pill-btn');
    if (!pill) return;

    const row = pill.closest('tr');
    if (!row) return;

    const status = pill.dataset.status;
    const input = row.querySelector('.status-input');
    const pills = row.querySelectorAll('.status-pill-btn');

    // Toggle logic: If clicking the active one, unselect it. Otherwise select it.
    if (pill.classList.contains(`active-${status.toLowerCase()}`)) {
      pill.classList.remove(`active-${status.toLowerCase()}`);
      input.value = '';
    } else {
      pills.forEach(p => {
        p.classList.remove('active-present', 'active-absent', 'active-late', 'active-excused', 'active-compensation');
      });
      pill.classList.add(`active-${status.toLowerCase()}`);
      input.value = status;
    }

    hasUnsavedChanges = true;
    updateCounters();
  });

  // Bulk Actions
  const btnMarkAllPresent = document.getElementById('btnMarkAllPresent');
  const btnMarkAllAbsent = document.getElementById('btnMarkAllAbsent');
  const btnClearAll = document.getElementById('btnClearAll');

  if (btnMarkAllPresent) {
    btnMarkAllPresent.addEventListener('click', function () {
      setBulkStatus('Present');
      hasUnsavedChanges = true;
    });
  }

  if (btnMarkAllAbsent) {
    btnMarkAllAbsent.addEventListener('click', function () {
      setBulkStatus('Absent');
      hasUnsavedChanges = true;
    });
  }

  if (btnClearAll) {
    btnClearAll.addEventListener('click', function () {
      setBulkStatus('');
      hasUnsavedChanges = true;
    });
  }

  function setBulkStatus(status) {
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(row => {
      // Only set for visible rows (respecting filter/search)
      if (row.style.display === 'none') return;

      const input = row.querySelector('.status-input');
      const pills = row.querySelectorAll('.status-pill-btn');

      pills.forEach(p => {
        p.classList.remove('active-present', 'active-absent', 'active-late', 'active-excused', 'active-compensation');
      });

      if (status) {
        input.value = status;
        const targetPill = row.querySelector(`.status-pill-btn[data-status="${status}"]`);
        if (targetPill) {
          targetPill.classList.add(`active-${status.toLowerCase()}`);
        }
      } else {
        input.value = '';
      }
    });

    updateCounters();
  }

  function updateCounters() {
    const rows = Array.from(table.querySelectorAll('tbody tr'));
    let present = 0, absent = 0, late = 0, excused = 0, comp = 0, unmarked = 0;

    rows.forEach(row => {
      const input = row.querySelector('.status-input');
      const val = input ? input.value : '';
      if (val === 'Present') present++;
      else if (val === 'Absent') absent++;
      else if (val === 'Late') late++;
      else if (val === 'Excused') excused++;
      else if (val === 'Compensation') comp++;
      else unmarked++;
    });

    const elTotal = document.getElementById('counterTotal');
    const elPresent = document.getElementById('counterPresent');
    const elAbsent = document.getElementById('counterAbsent');
    const elLate = document.getElementById('counterLate');
    const elExcused = document.getElementById('counterExcused');
    const elComp = document.getElementById('counterComp');
    const elUnmarked = document.getElementById('counterUnmarked');

    if (elTotal) elTotal.textContent = rows.length;
    if (elPresent) elPresent.textContent = present;
    if (elAbsent) elAbsent.textContent = absent;
    if (elLate) elLate.textContent = late;
    if (elExcused) elExcused.textContent = excused;
    if (elComp) elComp.textContent = comp;
    if (elUnmarked) elUnmarked.textContent = unmarked;

    const saveBarCount = document.getElementById('saveBarMarkedCount');
    if (saveBarCount) {
      const marked = present + absent + late + excused + comp;
      saveBarCount.textContent = `${marked} of ${rows.length} marked`;
    }
  }

  // Initial calculation on page load
  updateCounters();
}

// Search and Filter logic for table views
function initSearchAndFilter() {
  const searchInput = document.getElementById('tableSearchInput');
  const deptFilter = document.getElementById('deptFilterSelect');
  const table = document.getElementById('attendanceTable') || document.getElementById('attendeesTable') || document.getElementById('monthlyTable');

  if (!table) return;

  function filterRows() {
    const term = searchInput ? searchInput.value.toLowerCase().trim() : '';
    const dept = deptFilter ? deptFilter.value.trim() : '';
    const rows = table.querySelectorAll('tbody tr');

    rows.forEach(row => {
      const text = row.textContent.toLowerCase();
      const rowDept = row.dataset.dept || '';

      const matchesSearch = !term || text.includes(term);
      const matchesDept = !dept || rowDept === dept;

      if (matchesSearch && matchesDept) {
        row.style.display = '';
      } else {
        row.style.display = 'none';
      }
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', filterRows);
  }

  if (deptFilter) {
    deptFilter.addEventListener('change', filterRows);
  }
}

// Modal handling
function initModals() {
  const openButtons = document.querySelectorAll('[data-modal-open]');
  const closeButtons = document.querySelectorAll('[data-modal-close]');
  const overlays = document.querySelectorAll('.modal-overlay');

  openButtons.forEach(btn => {
    btn.addEventListener('click', function () {
      const modalId = this.dataset.modalOpen;
      const modal = document.getElementById(modalId);
      if (modal) modal.classList.add('open');
    });
  });

  closeButtons.forEach(btn => {
    btn.addEventListener('click', function () {
      const modal = this.closest('.modal-overlay');
      if (modal) modal.classList.remove('open');
    });
  });

  overlays.forEach(overlay => {
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) {
        overlay.classList.remove('open');
      }
    });
  });

  // Edit Attendee prefill
  const editButtons = document.querySelectorAll('.btn-edit-attendee');
  editButtons.forEach(btn => {
    btn.addEventListener('click', function () {
      const id = this.dataset.id;
      const identifier = this.dataset.identifier;
      const name = this.dataset.name;
      const dept = this.dataset.dept;
      const email = this.dataset.email;
      const days = this.dataset.days;
      const time = this.dataset.time;
      const target = this.dataset.target;
      const active = this.dataset.active;

      document.getElementById('editAttendeeId').value = id;
      document.getElementById('editAttendeeIdentifier').value = identifier;
      document.getElementById('editAttendeeName').value = name;
      document.getElementById('editAttendeeDept').value = dept;
      document.getElementById('editAttendeeEmail').value = email || '';
      if (document.getElementById('editAttendeeDays')) {
        document.getElementById('editAttendeeDays').value = days || '';
      }
      if (document.getElementById('editAttendeeTime')) {
        document.getElementById('editAttendeeTime').value = time || '';
      }
      if (document.getElementById('editAttendeeTarget')) {
        document.getElementById('editAttendeeTarget').value = target || 8;
      }
      document.getElementById('editAttendeeActive').value = active;

      const editModal = document.getElementById('editAttendeeModal');
      if (editModal) editModal.classList.add('open');
    });
  });

  // Log Compensation modal prefill
  const logCompButtons = document.querySelectorAll('.btn-log-compensation');
  logCompButtons.forEach(btn => {
    btn.addEventListener('click', function () {
      const studentId = this.dataset.id;
      const studentName = this.dataset.name;
      const studentReg = this.dataset.reg;

      const inputId = document.getElementById('logCompStudentId');
      const inputName = document.getElementById('logCompStudentName');
      if (inputId) inputId.value = studentId;
      if (inputName) inputName.textContent = `${studentName} (${studentReg})`;

      const modal = document.getElementById('logCompModal');
      if (modal) modal.classList.add('open');
    });
  });
}
